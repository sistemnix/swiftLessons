let num = 5e2
let hex = 0x5p2

let a = 5
let b = 5.0
//let c = a + b выведет ошибку т.к разные типы. Правильно будет так:
let c = a + Int(b) //Обрезает число до запятой, НЕ округляет
print(c)

//let c2 = 5 + 5.2

//Содание своего типа(псеводнима) данных
typealias myType = Double
let a1 = 5
let b1 = 5.2
let c1 = myType(a) + b1
print(c1)
 
//HOME WORK
print("HOME WORK 2")
//HW-1: вывести диапазоны типов
print("HW-1: вывести диапазоны типов")
    /*типы:
     Int
     Int8
     Int16
     Int32
     UInt
     Float
     UFloat
     Double
*/
print("Масимальное число у Int: \(Int.max)\n, максимальное отрицительное: \(Int.min)")
print("Масимальное число у Int8: \(Int8.max)\n, максимальное отрицительное: \(Int8.min)")
print("Масимальное число у Int16: \(Int16.max)\n, максимальное отрицительное: \(Int16.min)")
print("Масимальное число у Int32: \(Int32.max)\n, максимальное отрицительное: \(Int32.min)")
print("Масимальное число у Int: \(UInt.max)\n, максимальное отрицительное: \(UInt.min)")
//print("Масимальное число у Float: \(Float.max)\n, максимальное отрицительное: \(Float.min)")
//print("Масимальное число у Int: \(Double.max)\n, максимальное отрицительное: \(Double.min)")

/*HW-2:
 а)Создать три константы типа Int, Float ,Double
 б)Вывести суммы все трех в каждом типе
 в)Создать условие с типом Boolean%
 -Если Int < Double, то Double точнее
 -Если Int > Double, то любую фразу
 */
print("HW-2")
let numInt = 1
let numFloat : Float = 2.6
let numDouble = 6.33
//let sumNumIntFloat = numInt + numFloat
print("Сумма Int + Int(Float) = \(numInt + Int(numFloat)) используя FloatToInt")
print("Сумма Float(Int) + Float = \(Float(numInt) + numFloat) используя IntToFloat")
print("Сумма Int + Int(Double) = \(numInt + Int(numDouble)) используя DoubleToInt")
print("Сумма Double(Int) + Double = \(Double(numInt) + numDouble) используя IntToDouble")
print("Сумма Float + Float(Double) = \(numFloat + Float(numDouble)) используя DoubleToFloat")
print("Сумма Double(Float) + Double = \(Double(numFloat) + numDouble) используя FloatToDouble")

//HW-3
print("HW-3")
/*
 Содать условие: Если Int > Double, то Double точнее
 Если Int < Double, то Int проще.
 */
let sumInt = Int(Double(numInt) + Double(numFloat) + numDouble)
let sumFloat = Float(a) + numFloat + Float(numDouble)
let sumDouble = Double(numInt) + Double(numFloat) + numDouble

//УСЛОВИЕ
if Double(sumInt) < numDouble {
    print("Double is a greater!")
} else if Double(sumInt) == numDouble {
    print("Int is equal")
} else {
    print("Int is greater!")
}

print("sumInt =",  sumInt)

let a2 = 1
let b2 = 2.6
let c2 = Int(Double(a2) + b2)
print(c2)
